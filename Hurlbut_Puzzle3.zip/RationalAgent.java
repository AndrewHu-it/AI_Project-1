//Andrew Hurlbut
//AI/ML


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

public class RationalAgent {

    private Board goalState;
    private Board initialState;
    private Puzzle.SearchStrategy strategy;
    private int max_depth;

    HashMap<Board, Node> visited = new HashMap<Board, Node>();


    public RationalAgent(Board initialState, Board goalState, Puzzle.SearchStrategy strategy){
        this.goalState = goalState;
        this.initialState = initialState;
        this.strategy = strategy;
    }

    public RationalAgent(Board initialState, Board goalState, Puzzle.SearchStrategy strategy, int depth){
        this.goalState = goalState;
        this.initialState = initialState;
        this.strategy = strategy;
        this.max_depth = depth;
    }


    public  ArrayList<Puzzle.Direction> solve(){

        Node final_node = null;

        switch(this.strategy){
            case BFS: final_node =  this.BFS(); break;
            case DFS: final_node =  this.DFS(); break;
            case DLS: final_node =  this.DLS(); break;
            case ID: final_node = this.ID(); break;
        }

        if (final_node == null){
            return null;
        }
        ArrayList<Puzzle.Direction> path = final_node.backtrack();
        return path;
    }

    private Node BFS (){
        Queue<Node> queue = new LinkedList<>();
        Node startNode = new Node(initialState, null, null);
        queue.add(startNode);
        visited.put(initialState, startNode);

        while (!queue.isEmpty()) {
            //<<<STATS: CHECKING TO SEE WHAT THE MAX QUEUE SIZE IS!>>>
            if (queue.size()  > Puzzle.max_queue_size){
                Puzzle.max_queue_size = queue.size() ;
            }

            Node current = queue.poll();

            if (goalTest(current.getBoard())) {
                return current;
            }

            for (Puzzle.Direction direction : current.getBoard().valid_moves()) {
                Puzzle.states_expanded ++; //<<<STATS: WE ARE EXPANDING THE STATE>>>
                Board newBoard = current.getBoard().move(direction);
                if (!visited.containsKey(newBoard)) {
                    Node newNode = new Node(newBoard, current, direction);
                    Puzzle.states_created ++; //<<<STATS: WE ARE CREATING A NEW NODE HERE>>>
                    visited.put(newBoard, newNode);
                    queue.add(newNode);
                }
            }
        }

        return null;
    }


    private Node DFS (){
        Node node = new Node(initialState, null, null);
        this.max_depth = Integer.MAX_VALUE;
        return DLS(node, Integer.MAX_VALUE);
    }



    private Node DLS (){
        Node node = new Node(initialState, null, null);
        return DLS(node, max_depth);
    }

    private Node DLS(Node node, int limit) {
        if (node == null || limit <= 0) return null;
        int current_depth = this.max_depth - limit;

        Board currentBoard = node.getBoard();
        if (goalTest(currentBoard)) return node;


        if (!visited.containsKey(currentBoard)) {
            visited.put(currentBoard, node);
        }

        Puzzle.states_expanded ++;
        for (Puzzle.Direction direction : currentBoard.valid_moves()) {
            Board newBoard = currentBoard.move(direction);


            if (!visited.containsKey(newBoard)) {
                Node nextNode = new Node(newBoard, node, direction,current_depth);
                Puzzle.states_created ++;
                Node result = DLS(nextNode, limit - 1 );
                Puzzle.states_explored ++;
                if (result != null) {
                    if (goalTest(result.getBoard())) return result;
                }
            } else {

                Node old_node = visited.get(newBoard);
                int old_cost = old_node.getCost();
                if (old_node.getCost() > current_depth){ //this implies that we found a way to get to the node quicker, at which point we want to update it and explore it.
                    old_node.set_cost(current_depth);
                    old_node.set_lastMove(direction);
                    old_node.set_parent(node);

                    Node result = DLS(old_node, limit - 1 );
                    Puzzle.states_explored ++;
                    if (result != null) {
                        if (goalTest(result.getBoard())) return result;
                    }
                }
            }
        }
        return null;
    }




    private Node ID (){
        int limit = 1;
        while (true) {
            visited.clear();
            Node node = new Node(initialState, null, null);
            this.max_depth = limit;
            Node s = DLS(node, limit);
            if (s != null ) {
                return s;
            }
            limit++;
        }
    }






    public boolean goalTest(Board board){
        try {
            return goalState.equals(board);
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
        return false;
    }


}
